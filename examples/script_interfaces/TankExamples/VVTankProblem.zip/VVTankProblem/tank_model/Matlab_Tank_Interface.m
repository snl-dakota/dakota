% Matlab_Tank_Interface.m

% This script illustrates how to "drive" the Tank code using Matlab
% This is released as part of the 2014 Sandia National Laboratories V&V
% Challenge Problem.
% Last modified 20140318 by khu

%  1.	X_vec 		$1\times {{N}_{x}}$ vector, passed as comma delimited string, bounds $\left[ 0,\frac{L}{2} \right]$  (in)
%  2.	Phi_vec 	$1\times {{N}_{\varphi }}$ vector, passed as comma delimited string, bounds $\left[ 0,180 \right]$  (o)
% 		The code computes responses at all combinations of $x,\varphi$ to produce ${N_x}\times {N_\varphi}$ locations
%  3.	P		Scalar, bounds $\left[ 0,\infty  \right]$  (atm), (gage pressure)
%  4.	Gamma, -Chi	Scalar - Liquid specific weight OR composition
%  			Positive numbers interpreted as specific weight, bounds $\left[ 0,\infty  \right]$ (lbs/in3)
%  			Negative numbers $\left[ -1,0 \right]$ interpreted as negative composition
%  5.	H		Scalar (zero in the pressure only scenario) , bounds $\left[ 0,2R \right]$ (in)
%  6.	E		Scalar, bounds $\left[ 2.6e6,3.0e6 \right]$ (psi)
%  7.	Nu 		Scalar, bounds $\left[ 0.2,0.5 \right]$
%  8.	L 		Scalar, bounds $\left[ 0,\infty  \right]$ (in)
%  9.	R 		Scalar, bounds $\left[ 0,\infty  \right]$ (in)
%  10.	T		Scalar, bounds $\left[ 0,\infty  \right]$ (in)
%  11.	meshID		Mesh ID (choose from 1,2,3,4)
%  12.	summaryFile 	name of summary file, This writes out: 
%  	a.	Maximum von Mises Stress
%  	b.	$x$  index (note that python starts indexing from 0)
%  	c.	$\varphi $ index (note that python starts indexing from 0)
%  	d.	Surface - inner (-1) or outer (1)
%  13.	dataFile	Name of data file - if empty string, no dataFile is written. This writes out:
%  	a.	All inputs
%  	b.	Locations ($x$ and $\varphi $ )
%  	c.	Comma separated matrices for normal displacement (in), and stresses (psi) on the outside and inside surface of the tank $\left[ {{N}_{x}}\times {{N}_{\varphi }} \right]$ 

clear
home

%% example 1
X_vec = 3; %vector or scalar
Phi_vec = [0.9,1.1]; %vector or scalar
P = 10; % scalar
Gamma_Chi = 3.2; % scalar
H = 12; % scalar
E = 3e7; % scalar
Nu = .3; % scalar
L = 59; % scalar
R = 30; % scalar
T = 0.25; % scalar
meshID = 1; % scalar
summaryFile = 'FEMTankTest.summary'; % string
dataFile = 'FEMTankTest.data'; % string


%% Example 2
X_vec = rand(1,5)*50; %vector or scalar
Phi_vec = [0.9,1.1]; %vector or scalar
P = 10; % scalar
Gamma_Chi = -rand; % scalar
H = 12; % scalar
E = 3e7; % scalar
Nu = .3; % scalar
L = 59; % scalar
R = 30; % scalar
T = 0.25; % scalar
meshID = 3; % scalar
summaryFile = 'FEMTankTest.summary'; % string
dataFile = 'FEMTankTest.data'; % string


%% Example 3
load PandL_X_meas.txt
load PandL_Phi_meas.txt

load PandL_Tank3_NominalChi.txt
load PandL_Tank3_NominalGamma.txt
load PandL_Tank3_NominalHeight.txt
load PandL_Tank3_NominalP.txt

TestID = 1;

X_vec = PandL_X_meas.* (1 + 0.001*rand(size(PandL_X_meas))); %add tiny Gaussian noise to measurement locations
Phi_vec = PandL_Phi_meas.* (1 + 0.001*rand(size(PandL_Phi_meas))); %add tiny Gaussian noise to measurement locations
P = PandL_Tank3_NominalP(TestID); % scalar
Gamma_Chi = -PandL_Tank3_NominalChi(TestID); % scalar
H = PandL_Tank3_NominalHeight(TestID); % scalar
E = 3e7; % scalar
Nu = .3; % scalar
L = 59; % scalar
R = 30; % scalar
T = 0.25; % scalar
meshID = 3; % scalar
summaryFile = 'FEMTankTest.summary'; % string

% code word to write out a column of displacements to the summaryFile, k-th
% row corresponds to the k-th entry of X_vec and Phi_vec --> 
% Nrows = length(X_vec) = length(Phi_vec), if lengths aren't equal,
% something bad will happen.
dataFile = 'DisplacementsDataOnDiagonal'; 

% % code word to write out a column of displacements to the summaryFile,
% % including all combinations of X_vec and Phi_vec, index j from X_vec, and
% % index k from Phi_vec are printed to line (j-1) * length(Phi_vec) + k
% % Nrows = length(X_vec) * length(Phi_vec)
% dataFile = 'DisplacementsDataFullGrid'; 




%% Run
command = ['python -c"import FEMTank; FEMTank.main(', ...
    strrep( mat2str(X_vec), ' ', ','), ... arg1
    ', ', strrep( mat2str(Phi_vec), ' ', ','), ... arg2
    ', ', num2str(P), ... arg3
    ', ', num2str(Gamma_Chi), ... arg4
    ', ', num2str(H), ... arg5
    ', ', num2str(E), ... arg6
    ', ', num2str(Nu), ... arg7
    ', ', num2str(L), ... arg8
    ', ', num2str(R), ... arg9
    ', ', num2str(T), ... arg10
    ', ', num2str(meshID), ... arg11
    ', ''', summaryFile, '''', ... arg12
    ', ''', dataFile, '''', ... arg13
    ')"'];
disp(command)
CmdExitCode = system(command)



%% get results from (Normal) summaryFile
% special cases can be loaded directly
summaryFile_ID = fopen(summaryFile,'r');
line = fgetl(summaryFile_ID);
names={};
while line ~= -1
    [value, names{end+1}] = strtok(line);
    eval([ names{end} , ' = ', value, ';'] ) ;
    line = fgetl(summaryFile_ID);
end
fclose(summaryFile_ID);

names % list the variables that were loaded from summaryFile
