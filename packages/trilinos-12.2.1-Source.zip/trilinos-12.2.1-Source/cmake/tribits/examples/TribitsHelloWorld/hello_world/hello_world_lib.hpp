#include <string>

namespace HelloWorld { std::string getHelloWorld(); }
