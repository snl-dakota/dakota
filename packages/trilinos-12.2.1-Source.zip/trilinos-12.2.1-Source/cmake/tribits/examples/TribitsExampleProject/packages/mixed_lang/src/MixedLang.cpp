#include "MixedLang.hpp"

std::string tribits_mixed::mixedLang()
{
  return "Mixed Language";
}
