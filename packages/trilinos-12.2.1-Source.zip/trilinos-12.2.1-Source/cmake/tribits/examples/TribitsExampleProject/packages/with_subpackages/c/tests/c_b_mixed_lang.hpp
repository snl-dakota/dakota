#include <string>

namespace WithSubpackages {

std::string c_b_mixed_lang();

} 
