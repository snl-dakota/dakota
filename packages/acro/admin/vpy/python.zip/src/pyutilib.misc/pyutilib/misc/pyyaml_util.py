
__all__ = [ 'yaml_fix', 'load_yaml', 'extract_yaml', 'compare_yaml_repn', 'compare_yaml_strings', 'compare_yaml_files']

import pprint
import math
import re
import StringIO
try:
    import yaml
    yaml_available=True             #pragma:nocover
except ImportError:                 #pragma:nocover
    yaml_available=False            #pragma:nocover


def yaml_fix(val):
    if not isinstance(val,basestring):
        return val
    return val.replace(':','\\x3a')


def extract_yaml(stream, begin_str='', end_str=None):
    if isinstance(stream,basestring):
        _stream = open(stream, 'r')
    else:
        _stream = stream
    if end_str is None:
        end_str == begin_str
    ans = []
    status = False
    for line in _stream:
        tokens = re.split('[\t ]+',line.strip())
        if not status and line.startswith(begin_str):
            status = True
        elif not end_str is None and end_str != '' and line.startswith(end_str):
            break
        elif status:
            if tokens[0] != '#':
                ans.append(line)
    if isinstance(stream,basestring):
        _stream.close()
    return "\n".join(ans)


def load_yaml(str):
    istream = StringIO.StringIO(str)
    return yaml.load(istream, Loader=yaml.SafeLoader)


def compare_yaml_repn(baseline, output, tolerance=0.0, prefix="<root>", exact=True):
    if type(baseline) != type(output):
        raise IOError, "(%s) Structural difference:\nbaseline:\n%s\noutput:\n%s" % (prefix, pprint.pformat(baseline), pprint.pformat(output))
    #
    if type(baseline) is list:
        if not exact and len(baseline) > len(output):
            raise IOError, "(%s) Baseline has longer list than output:\nbaseline:\n%s\noutput:\n%s" % (prefix, pprint.pformat(baseline), pprint.pformat(output))
        if exact and len(baseline) != len(output):
            raise IOError, "(%s) Baseline list length does not equal output list:\nbaseline:\n%s\noutput:\n%s" % (prefix, pprint.pformat(baseline), pprint.pformat(output))
        j=0
        i=0
        while j < len(baseline) and i < len(output):
            try:
                compare_yaml_repn(baseline[j], output[i], tolerance=tolerance, prefix=prefix+"["+str(i)+"]", exact=exact)
                j += 1
            except Exception, msg:
                print msg
                pass
            i += 1
        if j < len(baseline):
            raise IOError, "(%s) Could not find item %d in output list:\nbaseline:\n%s\noutput:\n%s" % (prefix, j, pprint.pformat(baseline), pprint.pformat(output))
    #
    elif type(baseline) is dict:
        if exact and len(baseline.keys()) != len(output.keys()):
            raise IOError, "(%s) Baseline and output have different keys:\nbaseline:\n%s\noutput:\n%s" % (prefix, pprint.pformat(baseline), pprint.pformat(output))
        for key in baseline:
            if not key in output:
                raise IOError, "(%s) Baseline key %s that does not exist in output:baseline:\n%s\noutput:\n%s" % (prefix, key, pprint.pformat(baseline), pprint.pformat(output))
            compare_yaml_repn(baseline[key], output[key], tolerance=tolerance, prefix=prefix+"."+key, exact=exact)
    #
    elif (type(baseline) is float or type(output) is float) and type(baseline) in [int,float] and type(output) in [int,float]:
        if math.fabs(baseline-output) > tolerance:
            raise ValueError, "(%s) Floating point values differ: baseline=%f and output=%f (tolerance=%f)" % (prefix, baseline, output, tolerance)
    elif baseline != output:    #pragma:nocover
        raise ValueError, "(%s) Values differ:\nbaseline:\n%s\noutput:\n%s" % (prefix, pprint.pformat(baseline), pprint.pformat(output))


def compare_yaml_strings(baseline, output, tolerance=0.0, exact=True):
    if not yaml_available:      #pragma:nocover
        raise IOError, "Cannot compare YAML strings because YAML is not available"
    baseline_repn = load_yaml(baseline)
    output_repn = load_yaml(output)
    compare_yaml_repn(baseline_repn, output_repn, tolerance=tolerance, exact=exact)


def compare_yaml_files(baseline_fname, output_fname, tolerance=0.0, baseline_begin='', baseline_end='', output_begin='', output_end=None, exact=True):
    INPUT=open(baseline_fname,'r')
    baseline = extract_yaml(INPUT, begin_str=baseline_begin, end_str=baseline_end)
    INPUT.close()
    INPUT=open(output_fname,'r')
    output = extract_yaml(INPUT, begin_str=output_begin, end_str=output_end)
    INPUT.close()
    compare_yaml_strings(baseline, output, tolerance=tolerance, exact=exact)
