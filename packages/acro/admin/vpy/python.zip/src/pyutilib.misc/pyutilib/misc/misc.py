#  _________________________________________________________________________
#
#  PyUtilib: A Python utility library.
#  Copyright (c) 2008 Sandia Corporation.
#  This software is distributed under the BSD License.
#  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
#  the U.S. Government retains certain rights in this software.
#  _________________________________________________________________________


import copy
import errno
import filecmp
import linecache
import logging
import os
import re
import shutil
import stat
import string
import sys
import warnings
from pyutilib.misc.indent_io import StreamIndenter

if (sys.platform[0:3] == "win"): #pragma:nocover
    executable_extension=".exe"
else:                            #pragma:nocover
    executable_extension=""


def remove_chars_in_list(s, l):
    if len(l) == 0:
        return s

    schars = []
    for c in s:
        if c not in l:
            schars.append(c)

    snew = "".join(schars)

    return snew

def get_desired_chars_from_file(f, nchars, l=""):
    retBuf = ""
    while nchars > 0:
        buf = f.read(nchars)
        if len(buf) == 0:
            break

        buf = remove_chars_in_list(buf, l)
        nchars -= len(buf)
        retBuf = retBuf + buf

    return retBuf

def compare_file(filename1,filename2, ignore=["\t"," ","\n","\r"]):
    """
    Do a simple comparison of two files that ignores differences
    in newline types.

    The return value is the tuple: (status,lineno).  If status is True,
    then a difference has occured on the specified line number.  If
    the status is False, then lineno is None.

    The goal of this utility is to simply indicate whether there are
    differences in files.  The Python 'difflib' is much more comprehensive
    and consequently more costly to apply.  The shutil.filecmp utility is
    similar, but it does not ignore differences in file newlines.  Also,
    this utility can ignore an arbitrary set of characters.
    """
    if not os.path.exists(filename1):
        raise IOError, "compare_file: cannot find file `"+filename1+"'"
    if not os.path.exists(filename2):
        raise IOError, "compare_file: cannot find file `"+filename2+"'"

    if filecmp.cmp(filename1, filename2):
        return [False, None]

    INPUT1=open(filename1)
    INPUT2=open(filename2)
    lineno=0
    while True:

        # If either line is composed entirely of characters to
        # ignore, then get another one.  In this way we can
        # skip blank lines that are in one file but not the other

        line1 = ""
        while len(line1) == 0:
            line1=INPUT1.readline()
            if line1 == "":
                break
            line1 = remove_chars_in_list(line1, ignore)
            lineno = lineno + 1

        line2 = ""
        while len(line2) == 0:
            line2=INPUT2.readline()
            if line2 == "":
                break
            line2 = remove_chars_in_list(line2, ignore)

        if line1=="" and line2=="":
            return [False,None]

        if line1=="" or line2=="":
            return [True,lineno]

        index1=0
        index2=0
        while True:
            # Set the value of nc1
            if index1 == len(line1):
                nc1=None
            else:
                nc1=line1[index1]
            # Set the value of nc2
            if index2 == len(line2):
                nc2=None
            else:
                nc2=line2[index2]
            # Compare curent character values
            if nc1 != nc2:
                return [True,lineno]
            if nc1 is None and nc2 is None:
                break
            index1=index1+1
            index2=index2+1


def compare_large_file(filename1,filename2, ignore=["\t"," ","\n","\r"], bufSize=1 * 1024 * 1024):
    """
    Do a simple comparison of two files that ignores white space, or
    characters specified in "ignore" list.

    The return value is True if a difference is found, False otherwise.

    For very long text files, this function will be faster than
    compare_file() because it reads the files in by large chunks
    instead of by line.  The cost is that you don't get the lineno
    at which the difference occurs.
    """

    result = False

    if not os.path.exists(filename1):
        raise IOError, "compare_large_file: cannot find file `"+filename1+"'"
    if not os.path.exists(filename2):
        raise IOError, "compare_large_file: cannot find file `"+filename2+"'"

    if filecmp.cmp(filename1, filename2):
        return result

    f1Size = os.stat(filename1).st_size
    f2Size = os.stat(filename2).st_size

    INPUT1=open(filename1)
    INPUT2=open(filename2)

    while True:
        buf1 = get_desired_chars_from_file(INPUT1, bufSize, ignore)
        buf2 = get_desired_chars_from_file(INPUT2, bufSize, ignore)

        if len(buf1) == 0 and len(buf2) == 0:
            break
        elif len(buf1) == 0 or len(buf2) == 0:
            result = True
            break

        if len(buf1) != len(buf2) or buf1 != buf2 :
            result = True
            break

    INPUT1.close()
    INPUT2.close()
    return result


if sys.version_info[0:2] < (2, 5):
    def create_deepcopy( cls ):
        from copy import deepcopy
        from inspect import isfunction

        def deepcopy_for_python24 ( self, memo={} ):
            dup = cls( _deep_copying=True )

            for i in self.__dict__:
                item = self.__dict__[i]
                if isfunction(item) or \
                   isinstance(item, (int, long, float, bool, basestring)) or \
                   not hasattr(item, '__deepcopy__'):
                    dup.__dict__[i] = item
                else:
                    memo.update({id(item) : item })
                    dup.__dict__[i] = deepcopy( item, memo )

            return dup
        return deepcopy_for_python24


def deprecated ( deprecated_function ):
    """ Code slightly adapted from the Python Decorator Library

    This is a decorator which can be used to mark functions as deprecated.
    It will result in a warning being emitted when the function is used.

    Example use:

    @deprecated
    def some_func ( ):
        ...
    """

    def wrapper_function ( *args, **kwargs ):
        warnings.warn_explicit(
          "Use of deprecated function '%s'." % deprecated_function.__name__,
          category = DeprecationWarning,
          filename = deprecated_function.func_code.co_filename,
          lineno   = deprecated_function.func_code.co_firstlineno + 1
        )
        return deprecated_function( *args, **kwargs )
    return wrapper_function


def tostr(array):
    """ Create a string from an array of numbers """
    tmpstr = ""
    for val in array:
        tmpstr = tmpstr + " " + `val`
    return tmpstr.strip()


def flatten(x):
    """Flatten nested list"""
    result = []
    for el in x:
        if hasattr(el, "__iter__") and not isinstance(el, basestring):
            result.extend(flatten(el))
        else:
            result.append(el)
    return result

def flatten_tuple(val):
    """ Flatten nested tuples """
    if not isinstance(val,tuple):
        return val
    rv = ()
    for i in val:
        if isinstance(i,tuple):
            rv = rv + flatten_tuple(i)
        else:
            rv = rv + (i,)
    return rv




#
# A better method for removing directory trees, which handles MSWindows errors
# that are associated with read-only files.
#
def handleRemoveReadonly(func, path, exc):
    excvalue = exc[1]
    if func in (os.rmdir, os.remove) and excvalue.errno == errno.EACCES:
        os.chmod(path, stat.S_IRWXU| stat.S_IRWXG| stat.S_IRWXO) # 0777
        func(path)
    else:
        raise

def rmtree(dir):
    if not os.path.exists(dir):
        return
    shutil.rmtree(dir, ignore_errors=False, onerror=handleRemoveReadonly)


@deprecated
def recursive_delete(path,deleteRoot=True):
    """
    Recursively removes files and directories
    """
    if os.path.exists(path):
        for root, dirs, files in os.walk(path, topdown=False):
            for name in files:
                os.remove(os.path.join(root,name))
            for name in dirs:
                os.rmdir(os.path.join(root,name))
        if deleteRoot:
            os.rmdir(path)

def quote_split(re_str, str):
    """
    Split a string, but do not split the string between quotes.
    """
    mylist = []
    chars = []
    state = 1
    quote = []
    for token in re.split(re_str,str):
        prev = " "
        for character in token:
            if character is "'" or (character == "\"" and prev != "\\"):
                if state == 1:
                    chars.append(character)
                    quote.append(character)
                    state = 2
                elif character is quote[-1]:
                    state = 1
                    chars.append(character)
                    quote.pop()
            else:
                chars.append(character)
                prev = character
        if state == 1:
            if len(chars) > 0:
                mylist = mylist + [ string.join(chars,"") ]
                chars = []
        else:
            chars = chars + [ " " ]
    if state == 2:
        raise ValueError, "ERROR: unterminated quotation found in quote_split()"
    return mylist


def traceit(frame, event, arg):    #pragma:nocover
    """
    A utility for tracing Python executions.  Use this function by
    executing:

    sys.settrace(traceit)
    """
    if event == "line":
        lineno = frame.f_lineno
        try:
            filename = frame.f_globals["__file__"]
        except:
            return traceit
        if (filename.endswith(".pyc") or
            filename.endswith(".pyo")):
            filename = filename[:-1]
        name = frame.f_globals["__name__"]
        line = linecache.getline(filename, lineno)
        print "%s:%s: %s" % (name, lineno, line.rstrip())
    return traceit


def tuplize(dlist, d, name):
    """
    Convert a list into a list of tuples.
    """
    if len(dlist) % d != 0:
        raise ValueError, "Cannot tuplize data for set "+str(name)+" because its length " + str(len(dlist)) + " is not a multiple of dimen " + str(d)
    j = 0
    t = []
    rv = []
    for i in dlist:
        t.append(i)
        j += 1
        if j == d:
            rv.append(tuple(t))
            t = []
            j = 0
    return rv


def search_file(filename, search_path=None, implicitExt=executable_extension, executable=False, isfile=True, validate=None):
    """
    Given a search path, find a file.

    Can specify the following options:
       path - A list of directories that are searched
       executable_extension - This string is used to see if there is an
           implicit extension in the filename
       executable - Test if the file is an executable (default=False)
       isfile - Test if the file is file (default=True)
    """
    if search_path is None:
        #
        # Use the PATH environment if it is defined and not empty
        #
        if "PATH" in os.environ and os.environ["PATH"] != "":
            search_path = string.split(os.environ["PATH"], os.pathsep)
        else:
            search_path = os.defpath.split(os.pathsep)
    for path in search_path:
        if os.path.exists(os.path.join(path, filename)) and \
           (not isfile or os.path.isfile(os.path.join(path, filename))):
            if not executable or os.access(os.path.join(path,filename),os.X_OK):
                file = os.path.abspath(os.path.join(path, filename))
                if validate is None or validate(file):
                    return file
        if os.path.exists(os.path.join(path, filename+implicitExt)) and \
           (not isfile or os.path.isfile(os.path.join(path, filename+implicitExt))):
            if not executable or os.access(os.path.join(path,filename+implicitExt),os.X_OK):
                file = os.path.abspath(os.path.join(path, filename+implicitExt))
                if validate is None or validate(file):
                    return file
    return None


def sort_index(l):
    """Returns a list, where the i-th value is the index of the i-th smallest
    value in the data 'l'"""
    return list(index for index, item in sorted(enumerate(l), key=lambda
item: item[1]))


def count_lines(file):
    """Returns the number of lines in a file."""
    count = 0
    for line in open(file,"r"):
        count = count + 1
    return count


class Bunch(dict):
    """
    A class that can be used to store a bunch of data dynamically

    foo = Bunch(data=y, sq=y*y, val=2)
    print foo.data
    print foo.sq
    print foo.val

    Adapted from code developed by Alex Martelli and submitted to
    the ActiveState Programmer Network http://aspn.activestate.com
    """
    def __init__(self, **kw):
        dict.__init__(self,kw)
        self.__dict__.update(kw)


class Container(dict):
    """
    A generalization of Bunch.  This class allows all other attributes to have a
    default value of None.  This borrows the output formatting ideas from the
    ActiveState Code Container (recipe 496697).
    """

    def __init__(self, *args, **kw):
        for arg in args:
            for item in quote_split('[ \t]+',arg):
                r = item.find('=')
                if r != -1:
                    try:
                        val = eval(item[r+1:])
                    except:
                        val = item[r+1:]
                    kw[item[:r]] = val
        dict.__init__(self,kw)
        self.__dict__.update(kw)
        if not '_name_' in kw:
            self._name_ = self.__class__.__name__

    def set_name(self, name):
        self._name_ = name

    def __setitem__(self, name, val):
        self.__setattr__(name,val)

    def __getitem__(self, name):
        return self.__getattr__(name)

    def __setattr__(self, name, val):
        if name[0] != '_':
            dict.__setitem__(self, name, val)
        self.__dict__[name] = val

    def __getattr__(self, name):
        try:
            return dict.__getitem__(self, name)
        except:
            if name[0] == '_':
                raise AttributeError, "Unknown attribute %s" % name
        return None

    def __repr__(self):
        attrs = sorted("%s = %r" % (k, v) for k, v in self.__dict__.iteritems() if not k.startswith("_"))
        return "%s(%s)" % (self.__class__.__name__, ", ".join(attrs))

    def __str__(self):
        return self.as_string()

    def __str__(self, nesting = 1, indent='', print_name=True):
        attrs = []
        if not print_name:
            nesting -= 1
        indentation = indent+"    " * nesting
        for k, v in self.__dict__.iteritems():
            if not k.startswith("_"):
                text = [indentation, k, " = "]
                if isinstance(v, Container):
                    text.append(v.__str__(nesting + 1))
                else:
                    text.append(repr(v))
                attrs.append("".join(text))
        attrs.sort()
        if print_name:
            attrs.insert(0, indent+self._name_ + ":")
        return "\n".join(attrs)


class Options(Container):
    """
    This is a convenience class.  A common use of the Container class is to
    manage options that are passed into a class/solver/framework.  Thus,
    it's convenient to call this an Options object.
    """

    def __init__(self, *args, **kw):
        Container.__init__(self, *args, **kw)
        self.set_name('Options')


class LogHandler ( logging.Handler ):
    def __init__ ( self, base, *args, **kwargs ):
        if 'verbosity' in kwargs:
            self.verbosity = kwargs.pop('verbosity')
        else:
            self.verbosity = lambda: True
        logging.Handler.__init__(self, *args, **kwargs )

        self.basepath = base

    def emit(self, record):
        import sys   # why?  Isn't this imported above?
                     # Doesn't work w/o it though ... ?

        level    = record.levelname
        filename = record.pathname  # file path
        lineno   = record.lineno
        msg      = record.getMessage()
        try:
            function = record.funcName
        except AttributeError:
            function = '(unknown)'

        filename = filename.replace( self.basepath, '[base]' )

        if self.verbosity():
            sys.stdout.write('%(level)s: "%(fpath)s", %(lineno)d, '
                             '%(caller)s\n' %
                {
                  'level'  : level,
                  'fpath'  : filename,
                  'lineno' : lineno,
                  'caller' : function.strip(),
                }
            )
            StreamIndenter(sys.stdout, "\t").write(msg.strip()+"\n")
        else:
            lines = msg.splitlines(True)
            sys.stdout.write('%(level)s: %(msg)s\n' %
                {
                  'level'  : level,
                  'msg' : lines and lines.pop(0).strip() or '\n' ,
                }
            )
            if lines:
                StreamIndenter(sys.stdout, "\t").writelines(lines)
                if len(lines[-1]) and lines[-1][-1] != '\n':
                    sys.stdout.write('\n')
