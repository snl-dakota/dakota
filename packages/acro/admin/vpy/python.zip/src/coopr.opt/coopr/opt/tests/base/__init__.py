"""
coopr.opt unit tests
"""
