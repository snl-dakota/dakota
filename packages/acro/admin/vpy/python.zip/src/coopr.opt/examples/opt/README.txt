This directory will contain examples that illustrate the use of coopr.opt
optimizers.
