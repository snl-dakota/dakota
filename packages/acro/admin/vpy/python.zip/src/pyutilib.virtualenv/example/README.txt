
------------
venv_install
------------

Run 

  vpy_create venv.py venv_install

to create an installer that knows how to install a virtual environment
with virtualenv.


----------------
tevaspot_install
----------------

Run 

  vpy_create tevaspot.py tevaspot_install

to create an installer that knows how to install a virtual environment
with the tevaspot package installed.



