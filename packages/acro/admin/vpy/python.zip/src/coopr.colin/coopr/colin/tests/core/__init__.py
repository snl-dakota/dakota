"""
coopr.opt.colin unit tests
"""
