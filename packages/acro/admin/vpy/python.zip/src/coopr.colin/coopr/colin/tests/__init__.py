"""
coopr.core tests
"""
