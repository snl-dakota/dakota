Examples for coopr.colin:

 - colin: Illustrations of the use of coopr.colin's optimizers and COLIN
        XML interface.
