#  _________________________________________________________________________
#
#  PyUtilib: A Python utility library.
#  Copyright (c) 2008 Sandia Corporation.
#  This software is distributed under the BSD License.
#  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
#  the U.S. Government retains certain rights in this software.
#  _________________________________________________________________________
#

try:
    import yaml
    using_yaml=True
except ImportError:
    using_yaml=False

import plugins
from pyutilib.component.core import *


class YamlTestParser(SingletonPlugin):

    implements(plugins.ITestParser)

    def __init__(self, **kwds):
        SingletonPlugin.__init__(self, **kwds)
        self.name='yml'

    def load_test_config(self, filename):
        INPUT = open(filename, 'r')
        repn = yaml.load(INPUT, yaml.SafeLoader)
        INPUT.close()
        return repn

    def print_test_config(self, repn):
        print repn

    def enabled(self):
        return using_yaml
