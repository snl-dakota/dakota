# Imports
import pyutilib.th as unittest
import glob
import os
from os.path import dirname, abspath, abspath, basename
import sys

currdir = dirname(abspath(__file__))+os.sep
datadir = os.sep.join([dirname(dirname(dirname(dirname(abspath(__file__))))),'doc','workflow','examples'])+os.sep
#datadir = currdir

# Declare an empty TestCase class
class Test(unittest.TestCase): pass

# Find all example*.py files, and use them to define baseline tests
for file in glob.glob(datadir+'example*.py'):
    bname = basename(file)
    name=bname.split('.')[0]
    #
    # We use add_baseline_test instead of add_import_test because the latter does not seem to
    # work when running with nosetests
    #
    Test.add_baseline_test(cmd='%s %s' % (sys.executable, file),  baseline=datadir+name+'.txt', name=name, cwd=datadir, cmdfile=currdir+"cmd_"+name+".sh")

if not sys.platform.startswith('win'):
    # Find all *.sh files, and use them to define baseline tests
    for file in glob.glob(datadir+'*.sh'):
        bname = basename(file)
        name=bname.split('.')[0]
        #print file,bname,name
        Test.add_baseline_test(cmd='cd %s; %s' % (datadir, file),  baseline=datadir+name+'.txt', name=name)

# Execute the tests
if __name__ == '__main__':
    unittest.main()
