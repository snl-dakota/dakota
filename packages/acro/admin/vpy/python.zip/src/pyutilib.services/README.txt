========================
pyutilib.services README
========================

This Python package defines general services that are supported by
PyUtilib plugins.  For example, PyUtilib plugins are used to manage
temporary files in a general manner.


-------
License
-------

BSD.  See the LICENSE.txt file.


------------
Organization
------------

+ Directories

  * pyutilib - The root directory for PyUtilib source code

+ Documentation and Bug Tracking

  * Trac wiki: https://software.sandia.gov/trac/pyutilib
  * ChangeLog: https://software.sandia.gov/svn/public/pyutilib/pyutilib.services/trunk/CHANGELOG.txt

+ Authors

  * See the AUTHORS.txt file.

+ Project Managers

  * William E. Hart, wehart@sandia.gov

+ Mailing List

  * pyutilib-forum@googlegroups.com
    - The main list for help and announcements
  * pyutilib-developers@googlegroups.com
    - Where developers of PyUtilib discuss new features

--------------------
Third Party Software
--------------------

None.

